

parameter_struct = read_parameter_file("C:\Users\david\Documents\FEMM projects\MATLAB FEMM Z Motor\motor_parms_B.csv")

parameter = 'backiron_cut_angle';
parameter_sweep = 21.75;
parameter_struct.backiron_cut_thickness = 4.75;
% parameter_sweep = 90;
% parameter_struct.backiron_cut_thickness = 0;
% parameter_sweep = 12;
% parameter_struct.backiron_cut_thickness = 3;
output_result = zeros(size(parameter_sweep));

for i=1:length(parameter_sweep)
    parameter_struct.(parameter) = parameter_sweep(i);
    output = func_FEMM_VCM_seriesB(parameter_struct);
    output1_result(i) = output.force_constant./(output.backiron_mass + output.magnet_mass); % specific force constant (N/A/kg)
    output2_result(i) = output.force_constant %  force constant (N/A)
    output3_result(i) = (output.backiron_mass + output.magnet_mass) %  magnet+backiron mass
    output4_result(i,:) = output.Bx1_result;
    output5_result(i,:) = output.Bx1_ypts;
end


%%
figure(3)
plot(parameter_sweep,output2_result,'*-')
figure(4)
plot(parameter_sweep,output2_result./4.7257,'*-')

figure(5)
hold on
plot(output.Bx1_ypts,output.Bx1_result)
ylabel('Flux Density X Component (T)')
xlabel('Y axis position (mm) in center of air gap')