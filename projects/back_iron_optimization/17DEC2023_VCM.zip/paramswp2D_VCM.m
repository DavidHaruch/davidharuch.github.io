parameter_struct = read_parameter_file("C:\Users\david\Documents\FEMM projects\MATLAB FEMM Z Motor\motor_parms.csv")

parameter1 = 'backiron_cut_angle';
parameter1_sweep = 15:0.25:23;
parameter2 = 'backiron_cut_thickness';
parameter2_sweep = 4.75:-0.125:3;
%output_result = zeros(length(parameter1_sweep),length(parameter2_sweep));

for i=1:length(parameter1_sweep)
for j=1:length(parameter2_sweep)
    parameter_struct.(parameter1) = parameter1_sweep(i);
    parameter_struct.(parameter2) = parameter2_sweep(j);
    output = func_FEMM_VCM_seriesB(parameter_struct);
    output1_result(i,j) = output.force_constant./(output.backiron_mass + output.magnet_mass); % specific force constant (N/A/kg)
    output2_result(i,j) = output.force_constant; %  force constant (N/A)
    output3_result(i,j) = (output.backiron_mass + output.magnet_mass); %  magnet+backiron mass
end
end
%%
figure(1)
[X,Y] = meshgrid(parameter2_sweep,parameter1_sweep)
levels = [1:-0.001:0.985]
[C,h] = contourf(X,Y,output2_result./4.7257,levels)
clabel(C,h,levels)
xlabel(parameter2)
ylabel(parameter1)


figure(2)
[X,Y] = meshgrid(parameter2_sweep,parameter1_sweep)
surf(X,Y,output2_result./4.7257)
xlabel(parameter2)
ylabel(parameter1)


figure(3)
[X,Y] = meshgrid(parameter2_sweep,parameter1_sweep)
[C,h] = contourf(X,Y,output3_result./0.1915)
clabel(C,h)
xlabel(parameter2)
ylabel(parameter1)

figure(4)
[X,Y] = meshgrid(parameter2_sweep,parameter1_sweep)
[C,h] = contourf(X,Y,(output2_result./4.7257)./(output3_result./0.1915))
clabel(C,h)
xlabel(parameter2)
ylabel(parameter1)