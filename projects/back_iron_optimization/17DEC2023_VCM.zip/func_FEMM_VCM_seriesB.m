function output = func_FEMM_VCM(parameter_struct)
%%FEMM 2 sided Voice Coil Motor

openfemm;
newdocument(0);

mi_probdef(0,'millimeters','planar',1e-008,parameter_struct.problem_thickness,40,0);

% materials
backiron_material = '1010 Steel';
%backiron_material = 'Hiperco-50';
magnet_material = 'N50';
coil_material= '0.5mm';

mi_getmaterial('Air');
mi_getmaterial('N50');
mi_getmaterial('1010 Steel');
mi_getmaterial('0.5mm');

% define currents + and -
current = parameter_struct.current;
no_turns = 100;
mi_addcircprop('coilpositive',current,1);
mi_addcircprop('coilnegative',-current,1);

% all dimensions in mm unless otherwise stated

%% groups
% 0 --> magnets
% 1 --> coil
% 2 --> air
% 3 --> back iron

%coil
coil_thickness = parameter_struct.coil_thickness;
coil_height = parameter_struct.coil_height;
coil_gap = parameter_struct.coil_gap; % starts symetrically around 1/2 this value
air_gap = parameter_struct.air_gap; % per side distance from coil to magnet

%boundary
boundary_x = parameter_struct.boundary_x;
boundary_y = parameter_struct.boundary_y;

%magnets
magnet_thickness = parameter_struct.magnet_thickness;
halbach1_height = parameter_struct.halbach1_height;
normal1_height = parameter_struct.normal1_height;

%back iron
backiron_thickness = parameter_struct.backiron_thickness;
backiron_height = parameter_struct.backiron_height; % 36.35
start_of_back_iron_x = coil_thickness/2 + air_gap + magnet_thickness;
end_of_back_iron_x = start_of_back_iron_x+backiron_thickness;
end_of_cut_back_iron_x = start_of_back_iron_x+backiron_thickness-parameter_struct.backiron_cut_thickness;
back_iron_cut_delta_y = (end_of_back_iron_x - end_of_cut_back_iron_x)*(1/tand(parameter_struct.backiron_cut_angle));
top_of_back_iron_cut_y = backiron_height/2-back_iron_cut_delta_y;

%%

%draw boundary
mi_drawpolygon([boundary_x boundary_y; -boundary_x boundary_y; -boundary_x -boundary_y; boundary_x -boundary_y]);
mi_addblocklabel(boundary_x-1,boundary_y-1);
mi_selectlabel(boundary_x-1,boundary_y-1);
mi_setblockprop('Air',0,0,0,0,2,0);
mi_clearselected;

%draw upper coil
mi_drawpolygon([coil_thickness/2,coil_height+coil_gap/2;...
    coil_thickness/2,coil_gap/2;...
    -coil_thickness/2,coil_gap/2;...
    -coil_thickness/2,coil_height+coil_gap/2]);
%draw lower coil
mi_drawpolygon([coil_thickness/2,-coil_height-coil_gap/2;...
    coil_thickness/2,-coil_gap/2;...
    -coil_thickness/2,-coil_gap/2;...
    -coil_thickness/2,-coil_height-coil_gap/2]);
%label coils
mi_addblocklabel(0,coil_gap/2 + coil_height/2);
mi_selectlabel(0,coil_gap/2 + coil_height/2);
mi_setblockprop('0.5mm',0,0,'coilpositive',0,1,no_turns);
mi_clearselected;
mi_addblocklabel(0,-(coil_gap/2 + coil_height/2));
mi_selectlabel(0,-(coil_gap/2 + coil_height/2));
mi_setblockprop('0.5mm',0,0,'coilnegative',0,1,no_turns);
mi_clearselected;

%draw halbach
mi_drawrectangle(coil_thickness/2 + air_gap,halbach1_height/2,coil_thickness/2 + air_gap + magnet_thickness,-halbach1_height/2);
mi_drawrectangle(-coil_thickness/2 - air_gap,halbach1_height/2,-coil_thickness/2 - air_gap - magnet_thickness,-halbach1_height/2);
mi_addblocklabel(coil_thickness/2 + air_gap + magnet_thickness/2,0);
mi_selectlabel(coil_thickness/2 + air_gap + magnet_thickness/2,0);
mi_setblockprop('N50',0,0,0,90,0,0);
mi_clearselected;
mi_addblocklabel(-coil_thickness/2 - air_gap - magnet_thickness/2,0);
mi_selectlabel(-coil_thickness/2 - air_gap - magnet_thickness/2,0);
mi_setblockprop('N50',0,0,0,90+180,0,0);
mi_clearselected;

%draw magnets
mi_drawrectangle(coil_thickness/2 + air_gap,halbach1_height/2,coil_thickness/2 + air_gap + magnet_thickness,halbach1_height/2+normal1_height);
mi_drawrectangle(-(coil_thickness/2 + air_gap),halbach1_height/2,-(coil_thickness/2 + air_gap + magnet_thickness),halbach1_height/2+normal1_height);
mi_drawrectangle(coil_thickness/2 + air_gap, -halbach1_height/2, coil_thickness/2 + air_gap + magnet_thickness, -halbach1_height/2-normal1_height);
mi_drawrectangle(-(coil_thickness/2 + air_gap), -halbach1_height/2, -(coil_thickness/2 + air_gap + magnet_thickness), -halbach1_height/2-normal1_height);

mi_addblocklabel(-(coil_thickness/2 + air_gap + magnet_thickness/2),halbach1_height/2+normal1_height/2);
mi_selectlabel(-(coil_thickness/2 + air_gap + magnet_thickness/2),halbach1_height/2+normal1_height/2);
mi_setblockprop('N50',0,0,0,180,0,0);
mi_clearselected;

mi_addblocklabel(-(coil_thickness/2 + air_gap + magnet_thickness/2),-halbach1_height/2-normal1_height/2);
mi_selectlabel(-(coil_thickness/2 + air_gap + magnet_thickness/2),-halbach1_height/2-normal1_height/2);
mi_setblockprop('N50',0,0,0,0,0,0);
mi_clearselected;

mi_addblocklabel(coil_thickness/2 + air_gap + magnet_thickness/2,halbach1_height/2+normal1_height/2);
mi_selectlabel(coil_thickness/2 + air_gap + magnet_thickness/2,halbach1_height/2+normal1_height/2);
mi_setblockprop('N50',0,0,0,180,0,0);
mi_clearselected;

mi_addblocklabel(coil_thickness/2 + air_gap + magnet_thickness/2,-halbach1_height/2-normal1_height/2);
mi_selectlabel(coil_thickness/2 + air_gap + magnet_thickness/2,-halbach1_height/2-normal1_height/2);
mi_setblockprop('N50',0,0,0,0,0,0);
mi_clearselected;

%draw back irons
%mi_drawrectangle(start_of_back_iron_x,backiron_height/2,start_of_back_iron_x+backiron_thickness,-backiron_height/2);
%mi_drawrectangle(-start_of_back_iron_x,backiron_height/2,-start_of_back_iron_x-backiron_thickness,-backiron_height/2);
mi_drawpolygon([start_of_back_iron_x,backiron_height/2;...
    end_of_cut_back_iron_x,backiron_height/2;...
    end_of_back_iron_x,top_of_back_iron_cut_y;...
    end_of_back_iron_x,-top_of_back_iron_cut_y;...
    end_of_cut_back_iron_x,-backiron_height/2;...
    start_of_back_iron_x,-backiron_height/2]);

mi_drawpolygon([-start_of_back_iron_x,backiron_height/2;...
    -end_of_cut_back_iron_x,backiron_height/2;...
    -end_of_back_iron_x,top_of_back_iron_cut_y;...
    -end_of_back_iron_x,-top_of_back_iron_cut_y;...
    -end_of_cut_back_iron_x,-backiron_height/2;...
    -start_of_back_iron_x,-backiron_height/2]);

mi_addblocklabel(start_of_back_iron_x+backiron_thickness/2,0);
mi_selectlabel(start_of_back_iron_x+backiron_thickness/2,0);
mi_setblockprop('1010 Steel',0,0,0,0,3,0);
mi_clearselected;

mi_addblocklabel(-(start_of_back_iron_x+backiron_thickness/2),0);
mi_selectlabel(-(start_of_back_iron_x+backiron_thickness/2),0);
mi_setblockprop('1010 Steel',0,0,0,0,3,0);
mi_clearselected;

%mi_saveas('abc123')


mi_refreshview;
mi_zoomnatural;
mi_saveas(fullfile(pwd,'abc123.fem')); % this must be .fem
mi_analyse(1); % set param to 1 for no visible window
mi_loadsolution();

% extract results needed

% flux density at center of coil
point_sweep_y = -40/2:0.1:40/2;
point_sweep_x = zeros(size(point_sweep_y));
B_result = zeros(length(point_sweep_x),2);
B2_result = zeros(length(point_sweep_x),2);

for i=1:length(point_sweep_y)
    b_at_center_of_airgap(i,:) = mo_getb(point_sweep_x(i),point_sweep_y(i));
    output.Bx2_result(i,:) = mo_getb(start_of_back_iron_x+backiron_thickness/2,point_sweep_y(i));
end

mo_groupselectblock(1)
output.coil_force = abs(mo_blockintegral(12)); % lorentz force
mo_clearblock()
output.force_constant = output.coil_force./current; % lorentz force / current
%output.center_of_coil_B_curve = B_result;
%output.center_of_coil_B_max = max(B_result(:,1));
output.Bx1_result = b_at_center_of_airgap(:,1);
output.Bx1_ypts = point_sweep_y;
output.Bx1_xpts = point_sweep_x;

% magnet mass
mo_groupselectblock(0)
output.magnet_area = mo_blockintegral(5); % meters squared
output.magnet_volume = mo_blockintegral(10); % meters cubed
output.magnet_mass = output.magnet_volume.*parameter_struct.magnet_density; %kg
mo_clearblock()

% back iron mass
mo_groupselectblock(3)
output.backiron_area = mo_blockintegral(5); % meters squared
output.backiron_volume = mo_blockintegral(10); % meters cubed
output.backiron_mass = output.backiron_volume.*parameter_struct.backiron_density; %kg

end