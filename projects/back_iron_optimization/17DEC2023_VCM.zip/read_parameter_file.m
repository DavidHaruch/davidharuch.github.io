function outstruct = read_parameter_file(filename)
% reads a parameter file in the form of a CSV
% stores the identified parameters into a struct
TC = table2cell(readtable(filename));
outstruct = cell2struct(TC(:,2), TC(:,1), 1);
end